import React, { Component } from "react";
import { Link } from "react-router-dom";
import "../styles/Vseproduc.css";

class Vseproduc extends Component {
  state = {};

  componentDidMount = () => {
    let categoriya = ["ВСЕ ПРОДУКЦИЯ"],
      i;
    for (i = 0; i < this.props.mahsulot.length; i++) {
      if (!categoriya.includes(this.props.mahsulot[i].category)) {
        categoriya.push(this.props.mahsulot[i].category);
      }
    }
    this.setState({
      categoriya: categoriya,
    });
  };

  render() {
    return (
      <div>
        <div className="section">
          <div className="container">
            <h1 className="mainHr mb-4">Наша продукция</h1>
            <nav className="mb-5 w-75 mx-auto">
              <div className="nav nav-tabs mx-auto" id="nav-tab" role="tablist">
                {this.state.categoriya &&
                  this.state.categoriya.map((item, index) => (
                    <button
                      key={index}
                      className={`nav-link mx-auto ${
                        index === 0 ? "active" : ""
                      }`}
                      id={`nav-${index}`}
                      data-bs-toggle="tab"
                      data-bs-target={`#nav-${index}`}
                      type="button"
                      role="tab"
                    >
                      {item}
                    </button>
                  ))}
              </div>
            </nav>
            <div className="tab-content" id="nav-tabContent"> 
              {this.props.mahsulot &&
                this.props.mahsulot.map((item2, index2) => (
                  <div
                    className={`tab-pane ${index2 === 0 ? "active" : ""}`}
                    id={`nav-${index2}`}
                    role="tabpanel"
                    aria-labelledby={`nav-${index2}`}
                  >
                    <div className="row">
                      {this.props.mahsulot.map((item, index) => (
                        <div
                          key={index}
                          className="col-lg-3 col-md-6 col-sm-12 mb-4 boxes"
                        >
                          <Link
                            className="text-decoration-none"
                            to={`/Rezinka/${item.id}`}
                          >
                            <div className="card" style={{ width: "15rem" }}>
                              <img
                                src={item.urlImg}
                                className="card-img-top"
                                alt="img"
                              />
                              <hr className="w-100 mx-auto" />
                              <div className="card-body">
                                <Link to="/" className="link">
                                  {item.link}
                                </Link>
                              </div>
                            </div>
                          </Link>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              {/* <div
                className="tab-pane fade"
                id="nav-profile"
                role="tabpanel"
                aria-labelledby="nav-profile-tab"
              >
                <div className="row">
                  {this.props.mahsulot
                    .filter((myItem) => myItem.category === "резинка")
                    .map((item, index) => (
                      <div
                        key={index}
                        className="col-lg-3 col-md-6 col-sm-12 mb-4 boxes"
                      >
                        <div className="card" style={{ width: "15rem" }}>
                          <img
                            src={`images/${item.urlImg}`}
                            className="card-img-top"
                            alt="img"
                          />
                          <hr className="w-100 mx-auto" />
                          <div className="card-body">
                            <Link to="/" className="link">
                              {item.link}
                            </Link>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
              <div
                className="tab-pane fade"
                id="nav-contact"
                role="tabpanel"
                aria-labelledby="nav-contact-tab"
              >
                <div className="row">
                  {this.props.mahsulot
                    .filter((myItem) => myItem.category === "Шнурки")
                    .map((item, index) => (
                      <div
                        key={index}
                        className="col-lg-3 col-md-6 col-sm-12 mb-4 boxes"
                      >
                        <div className="card" style={{ width: "15rem" }}>
                          <img
                            src={`images/${item.urlImg}`}
                            className="card-img-top"
                            alt="img"
                          />
                          <hr className="w-100 mx-auto" />
                          <div className="card-body">
                            <Link to="/" className="link">
                              {item.link}
                            </Link>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Vseproduc;
