import React, { Component } from "react";

class Xatolik extends Component {
  render() {
    return (
      <div>
        <div className="container">
          <h1 className="p-5">Mavjud bolmagan page</h1>
        </div>
      </div>
    );
  }
}

export default Xatolik;
